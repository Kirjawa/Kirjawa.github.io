Desk-based habitat pre-map, Fenwick Solar Farm (EN010152): demonstration on open data
Ana Silva, November 2026. https://kirjawa.github.io/habitat-premap.html

This is a demonstration on open data. It is not a field survey and has not been signed off by an ecologist.
Habitat types are broad types from satellite data and LiDAR; condition, species and finer types are left to the survey.

Files
- fenwick_premap_demo.gpkg: habitat_parcels (class, area, evidence), hedgerows_lidar, solar_site_boundary. British National Grid (EPSG:27700).
- fenwick_premap_baseline_table.csv: one row per parcel, in the order of the statutory biodiversity metric's on-site habitat
  baseline inputs. Areas are rounded to 0.01 ha so that they add up to the site total.
- fenwick_premap_10m.tif: the pre-map at 10 m. Codes: 1 cropland, 2 grassland, 3 woodland and scrub, 4 built, 5 water,
  6 sparse or sealed ground, 7 hedgerow strip, 0 unclear (check on the walkover).

Sources and licences
- Contains modified Copernicus Sentinel data (2017-2026): Sentinel-2 L2A via Earth Search, Sentinel-1 RTC via Microsoft Planetary Computer.
- LiDAR Composite DTM and DSM, 1 m: (c) Environment Agency copyright and/or database right. Open Government Licence.
- Recorded Flood Outlines and rain gauge data: (c) Environment Agency copyright and/or database right. Open Government Licence.
- Crop Map of England (CROME) 2020-2024: Rural Payments Agency. Open Government Licence.
- Order limits: Planning Data platform, infrastructure-project dataset. Open Government Licence.
- ERA5-Land: generated using Copernicus Climate Change Service information (2026).
The surveyed baseline (AECOM, Fenwick Solar Farm Biodiversity Net Gain Assessment, EN010152/APP/7.11) is cited for comparison
and is not reproduced here.
