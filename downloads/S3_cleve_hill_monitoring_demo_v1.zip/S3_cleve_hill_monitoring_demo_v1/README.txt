Monitoring a solar park between survey visits: Cleve Hill Solar Park (EN010085), demonstration on open data
Ana Silva, November 2026. https://kirjawa.github.io/solar-monitoring.html

A demonstration on open data, not client work. Not a site visit and not a compliance assessment: satellite data shows where
and when something changed; the ecologists and the Habitat Management Steering Group judge what it means.

Contents
- cleve_hill_monitoring_demo.gpkg (British National Grid, EPSG:27700)
  arrays_mapped: the arrays mapped from Sentinel-2 (median NDMI below -0.30 since 1 July 2025)
  habitat_area_approximation: land in the Order limits east of the compound that the Crop Map of England shows as arable in
    2020 to 2022 and as grass in 2024. An approximation for monitoring; the agreed boundary is the steering group's.
  habitat_area_beyond_50m_exclusions: the same, beyond 50 m of the arrays and transformers, flood defence crests and road
    edges, and outside designated sites, as the outline management plan defines functional land.
- module_date.tif: first clear Sentinel-2 view with modules, per 10 m pixel, in days since 1 January 2023 (0 = none)
- steel_date.tif: first radar rise of 3 dB or more over the 2021 to 2023 level, per 100 m cell, days since 1 January 2023
- construction_progress.csv: share of the mapped arrays with steel (Sentinel-1) and modules (Sentinel-2, and Sentinel-1) by day
- habitat_area_record.csv: every Sentinel-2 view of the habitat area: clear share, median NDVI and BSI, share with bare soil
- habitat_area_management_signals.csv: NDVI falls of more than 0.2 between clear views on at least a quarter of the area
- habitat_area_winter_water.csv: open water per winter (Sentinel-1 and Sentinel-2) and winter rainfall

Sources and licences
- Contains modified Copernicus Sentinel data (2017 to 2026): Sentinel-2 L2A via Earth Search, Sentinel-1 RTC via Microsoft
  Planetary Computer.
- Order limits: Planning Data platform (Planning Inspectorate). The Swale SSSI, SPA and Ramsar: Natural England. Crop Map of
  England 2020 to 2024: Rural Payments Agency. Flood defences and rain gauges: Environment Agency. All: Contains public sector
  information licensed under the Open Government Licence v3.0.
- ERA5-Land: generated using Copernicus Climate Change Service information (2026).
- Roads: (c) OpenStreetMap contributors, ODbL (used for the 50 m road exclusion only).
- Commitments cited from the Outline Landscape and Biodiversity Management Plan, Rev E (November 2019, EN010085-001707);
  milestones from the project's community newsletter (June 2024) and Quinbrook (1 July 2025).
