Site screening for lender standards and nature disclosures: demonstration on open data
Ana Silva, November 2026. https://kirjawa.github.io/site-screening.html

This is a demonstration on open data, not client work. It is a screening, not an assessment: a flag means look closer,
never a finding about a site. It has not been reviewed by a biodiversity specialist.

Contents
- S2_site_screening_results.csv: one row per site, 1237 sites (504 in Bulgaria, 733 in mainland Portugal).
- S2_site_screening_demo.gpkg: the same, with each site's footprint (layer "sites", EPSG:4326).

Sites
Solar parks and wind farms mapped as power plants in OpenStreetMap (data of 2026-10-22), and wind turbines outside them, grouped
into a farm when they stand within 800 m of each other (Dunnett et al. 2020). A wind farm's footprint is the outline of its
turbines plus 150 m. Sites under 1 ha are left out. "source" gives the OpenStreetMap object, or the first turbine of a group.

Columns
asset_id, country, type, name          Site id (this screening's own), country, solar or wind, name where mapped
lat, lon                               Centre of the footprint (WGS 84)
turbines                               Wind turbines in the farm (OpenStreetMap)
area_ha                                Footprint area
natura2000                             inside / within 1 km / within 5 km / beyond 5 km
natura2000_distance_m                  Distance to the nearest Natura 2000 site (0 = overlapping)
natura2000_share_of_footprint          Share of the footprint inside Natura 2000
natura2000_sites_within_1km            Site codes, Natura 2000 end-2024 release
birds_directive_site_distance_m        Distance to the nearest Birds Directive site (SPA)
critical_habitat_basic                 Critical Habitat screening layer (basic): likely or potential, on site or within 1 km
aqueduct_physical_risk_quantity        Aqueduct 4.0, physical risk, water quantity (baseline, default weighting)
aqueduct_physical_risk_quality         Aqueduct 4.0, physical risk, water quality
aqueduct_overall_water_risk            Aqueduct 4.0, overall water risk (includes regulatory and reputational risk)
aqueduct_baseline_water_stress         Aqueduct 4.0, baseline water stress (as used by ESRS E3 and GRI 303)
biodiversity_intactness_1km_2020       Biodiversity Intactness Index, mean within 1 km of the footprint (footprint excluded), 2020
biodiversity_intactness_change_2017_2020   Its change from 2017 to 2020
footprint_natural_cover_2021           Share of the footprint under trees, shrubs, grass or wetland in ESA WorldCover 2021
tnfd_important_for_biodiversity        Natura 2000 or likely critical habitat, inside or within 1 km
tnfd_high_integrity                    Intactness within 1 km in the country's top quarter (2020)
tnfd_integrity_decline                 Fall within 1 km, 2017 to 2020, steeper than on 95% of the country's land
tnfd_high_water_risk                   Aqueduct physical risk, quantity or quality, high or extremely high
tnfd_sensitive_location                Any of the four criteria above
ps6_pr6_screening                      Assessment likely: inside Natura 2000 or on likely critical habitat.
                                       Check: within 1 km of either. No flag from open data: neither.
wind_within_5km_of_birds_site          Wind farm within 5 km of a Birds Directive site
priority_location                      Assessment likely, or wind within 5 km of a Birds Directive site
tree_loss_1km_2017_2025_ha             Tree cover lost within 1 km of the footprint (footprint excluded), Hansen/UMD GFC 2025 v1.13
tree_loss_1km_wildfire_ha              The part of it in 1 km cells whose main driver is wildfire (WRI/Google DeepMind v1.13)
tree_loss_1km_<year>_ha                The same, year by year, 2017 to 2025
natural_cover_lost_1km_ha              Natural cover (trees, rangeland, flooded vegetation) that became crops, built-up or bare and
                                       stayed so: same group in 2017 and 2018, another in 2022 and 2023 (Impact Observatory v2)
natural_cover_gained_1km_ha            The reverse
natural_net_loss_share_1km             (lost - gained) / land within 1 km
tree_loss_share_1km                    tree_loss_1km_2017_2025_ha / land within 1 km
notable_loss_within_1km                At least 5% of the land within 1 km lost natural cover (net) or tree cover

What this screening can't tell
Key biodiversity areas and species records (not open for this use; the critical habitat layer stands in for them at about
1 km resolution), whether qualifying species are present, ecosystem services for local communities, and exact site
boundaries. A client's own site register would replace the OpenStreetMap list.

Licences and attribution
This database is derived from OpenStreetMap and is made available under the Open Database License (ODbL) 1.0:
https://opendatacommons.org/licenses/odbl/1-0/ . Site locations © OpenStreetMap contributors.
Screening attributes are derived from:
- Natura 2000, end-2024 release: European Environment Agency and DG ENV, CC BY 4.0
- Critical Habitat screening layer, basic: UNEP-WCMC and The Biodiversity Consultancy (Dunnett et al. 2025), CC BY 4.0
- Aqueduct 4.0: World Resources Institute (Kuzma et al. 2023), CC BY 4.0
- Biodiversity Intactness Index: Impact Observatory and Vizzuality, CC BY 4.0
- ESA WorldCover 2021 v200 (Zanaga et al. 2022), CC BY 4.0
- Global Forest Change 2025 v1.13: Hansen/UMD/Google/USGS/NASA (Hansen et al. 2013), CC BY 4.0
- Drivers of tree cover loss v1.13: WRI and Google DeepMind (Sims et al. 2025), CC BY 4.0
- 10 m annual land use land cover v2: Impact Observatory, Microsoft and Esri, CC BY 4.0
Not used: WDPA and key biodiversity area data, and the non-commercial drill-down version of the critical habitat layer.

Sources
Dunnett, S. et al. (2025). An update to the global Critical Habitat screening layer. Scientific Data 12, 1812.
Dunnett, S. et al. (2020). Harmonised global datasets of wind and solar farm locations and power. Scientific Data 7, 130.
Kuzma, S. et al. (2023). Aqueduct 4.0: updated decision-relevant global water risk indicators. World Resources Institute.
Zanaga, D. et al. (2022). ESA WorldCover 10 m 2021 v200. Zenodo.
Hansen, M. C. et al. (2013). High-resolution global maps of 21st-century forest cover change. Science 342, 850-853.
Sims, M. J. et al. (2025). Global drivers of forest loss at 1 km resolution. Environmental Research Letters 20, 074027.
